from wtforms import Form, StringField, RadioField, SelectField, TextAreaField, validators,IntegerField,FloatField
from wtforms.fields import EmailField, DateField ,FileField
from flask_wtf.file import FileAllowed,FileRequired
import re
import shelve
from flask import request



class CapitalLetterValidator(object):
    def __init__(self, message=None):
        if not message:
            message = u'First letter must be a capital letter.'
        self.message = message

    def __call__(self, form, field):
        if not re.match("^[A-Z].*", field.data):
            raise validators.ValidationError(self.message)



class PositiveIntegerValidator(object):
    def __init__(self, message=None):
        if not message:
            message = u'This field must contain a positive integer.'
        self.message = message

    def __call__(self, form, field):
        if not isinstance(field.data, float) or field.data < 0:
            raise validators.ValidationError(self.message)






class Addproductform(Form):
    p_name = StringField('Product Name',[validators.length(min=1, max=150),validators.DataRequired(),CapitalLetterValidator()])
    price=FloatField('Price',[validators.DataRequired(),PositiveIntegerValidator()])
    discount=IntegerField('Discount',default=0)
    stock=IntegerField('stock',[validators.DataRequired()])
    description=TextAreaField('Description',[validators.DataRequired()])


