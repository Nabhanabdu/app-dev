from flask import Flask, render_template, request, redirect, url_for
from Forms import Addproductform
import shelve,Product
# from flask_uploads import UploadSet,configure_uploads,IMAGES ,patch_request_class
# import os

import stripe




# basedir = os.path.abspath(os.path.dirname(__file__))


app = Flask(__name__)
# app.config['UPLOADED_PHOTOS_DEST'] = os.path.join(basedir,'static/images')
# photos = UploadSet('photos', IMAGES)
# configure_uploads(app, photos)
# patch_request_class(app)




@app.route('/')
def home():
    products_dict = {}
    db = shelve.open('product.db', 'r')
    products_dict = db['Products']
    db.close()

    products_list = []
    for key in products_dict:
        product = products_dict.get(key)
        products_list.append(product)

    return render_template('home.html', count=len(products_list), products_list=products_list)







@app.route('/contactUs')
def contact_us():
    return render_template('contactUs.html')




@app.route('/addproduct', methods=['GET', 'POST'])
def add_product():
    add_product_form = Addproductform(request.form)
    if request.method == 'POST' and add_product_form.validate():
        products_dict = {}
        db = shelve.open('product.db','c')

        try:
            products_dict = db['Products']
        except:
            print("Error in retrieving products from product.db.")

        product = Product.Product(add_product_form.p_name.data, add_product_form.price.data, add_product_form.discount.data, add_product_form.stock.data, add_product_form.description.data)
        products_dict[product.get_product_id()] = product
        db['Products'] = products_dict

        db.close()

        return redirect(url_for('retrieve_products'))
    return render_template('addproduct.html', form=add_product_form)









@app.route('/retrieveProducts')
def retrieve_products():
    products_dict = {}
    db = shelve.open('product.db', 'r')
    products_dict = db['Products']
    db.close()

    products_list = []
    for key in products_dict:
        product = products_dict.get(key)
        products_list.append(product)

    return render_template('retrieveProducts.html', count=len(products_list), products_list=products_list)



@app.route('/updateproduct/<int:id>/', methods=['GET', 'POST'])
def update_product(id):
    update_product_form = Addproductform(request.form)
    if request.method == 'POST' and update_product_form.validate():
        products_dict = {}
        db = shelve.open('product.db', 'w')
        products_dict = db['Products']

        product = products_dict.get(id)
        product.set_p_name(update_product_form.p_name.data)
        product.set_price(update_product_form.price.data)
        product.set_discount(update_product_form.discount.data)
        product.set_stock(update_product_form.stock.data)
        product.set_description(update_product_form.description.data)


        db['Products'] = products_dict
        db.close()

        return redirect(url_for('retrieve_products'))
    else:
        products_dict = {}
        db = shelve.open('product.db', 'r')
        products_dict = db['Products']
        db.close()

        product = products_dict.get(id)
        update_product_form.p_name.data = product.get_p_name()
        update_product_form.price.data = product.get_price()
        update_product_form.stock.data = product.get_stock()
        update_product_form.discount.data = product.get_discount()
        update_product_form.description.data = product.get_description()


        return render_template('updateproducts.html', form=update_product_form)






@app.route('/deleteproduct/<int:id>', methods=['POST'])
def delete_product(id):
    products_dict = {}
    db = shelve.open('product.db', 'w')
    products_dict = db['Products']
    products_dict.pop(id)

    db['Products'] = products_dict
    db.close()

    return redirect(url_for('retrieve_products'))






if __name__ == '__main__':
    app.run(debug=True)

